<?xml version="1.0" encoding="UTF-8"?>
<tileset name="extras" tilewidth="48" tileheight="48" tilecount="176">
 <image source="tileset_extras.png" width="384" height="1056"/>
 <tile id="0">
  <animation>
   <frame tileid="0" duration="80"/>
   <frame tileid="8" duration="80"/>
   <frame tileid="16" duration="80"/>
   <frame tileid="24" duration="80"/>
   <frame tileid="32" duration="80"/>
   <frame tileid="40" duration="80"/>
   <frame tileid="48" duration="80"/>
   <frame tileid="56" duration="80"/>
  </animation>
 </tile>
 <tile id="1">
  <animation>
   <frame tileid="1" duration="90"/>
   <frame tileid="9" duration="90"/>
   <frame tileid="17" duration="90"/>
   <frame tileid="25" duration="90"/>
   <frame tileid="33" duration="90"/>
   <frame tileid="41" duration="90"/>
   <frame tileid="49" duration="90"/>
   <frame tileid="57" duration="90"/>
  </animation>
 </tile>
 <tile id="2">
  <animation>
   <frame tileid="2" duration="80"/>
   <frame tileid="10" duration="80"/>
   <frame tileid="18" duration="80"/>
   <frame tileid="26" duration="80"/>
   <frame tileid="34" duration="80"/>
   <frame tileid="42" duration="80"/>
   <frame tileid="50" duration="80"/>
   <frame tileid="58" duration="80"/>
  </animation>
 </tile>
</tileset>
